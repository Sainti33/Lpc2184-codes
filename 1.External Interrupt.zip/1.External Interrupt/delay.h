#ifndef __DELAY_H
#define __DELAY_H
void delay_ms(unsigned long);
void delay_us(unsigned long);
#endif
